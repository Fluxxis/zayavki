// ВАЖНО: вставь сюда свой Discord Webhook URL
// Пример: https://discord.com/api/webhooks/.../... 
// НИКОГДА не вставляй сюда токен Telegram-бота.
window.APP_CONFIG = {
  DISCORD_WEBHOOK_URL: "PUT_YOUR_DISCORD_WEBHOOK_URL_HERE",
  TARGET_BOT_LINK: "https://t.me/IpachiBot?start=7225974704",
  APP_NAME: "Заявки"
};
